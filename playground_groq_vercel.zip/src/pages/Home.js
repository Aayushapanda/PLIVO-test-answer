import React from 'react';
export default function Home() {
  return <div style={{padding: '2rem'}}>Welcome to Groq Playground</div>;
}